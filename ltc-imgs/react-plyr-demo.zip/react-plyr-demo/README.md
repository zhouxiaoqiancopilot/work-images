# react-plyr-demo

[![Greenkeeper badge](https://badges.greenkeeper.io/chintan9/react-plyr-demo.svg)](https://greenkeeper.io/)

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/react-plyr-demo)


Inspired from https://github.com/sampotts/plyr/issues/254#issuecomment-543463813
